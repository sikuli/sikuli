def dragLeft(t):
  dragDrop(t,  [t.x - 200,   t.y])

def dragRight(t):
  dragDrop(t,  [t.x + 200,   t.y])


switchApp("System Preferences.app")
click("1254427520117.png")
thumbs = findAll(Pattern("1254425961872.png").similar(0.48))
for t in list(thumbs)[:2]: # only take the first two 
  dragLeft(t) # off
  #dragRight(t)  # on
