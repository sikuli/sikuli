from org.python.tests import Invisible
Invisible.protectedStaticMethod(7)
Invisible().protectedMethod(7)
Invisible.packageStaticMethod()
Invisible().packageMethod()
